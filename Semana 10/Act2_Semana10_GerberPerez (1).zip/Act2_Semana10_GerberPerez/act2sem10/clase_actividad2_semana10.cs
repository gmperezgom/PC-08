﻿using System.ComponentModel;

class actividad2_semana10{
    static void Main(){
        double sumaNumeros=0;
        double promedioNumeros=0;
        double [] numeros= new double[8];
        for (int i = 0; i < 8; i++)
        {
            Console.WriteLine($"Ingresa el nummero en la posicion {i}");
            numeros[i]=Convert.ToDouble(Console.ReadLine());
            sumaNumeros+=numeros[i];
        }
        Console.WriteLine("El arreglo es el siguiente:");
        for (int i = 0; i < 8; i++)
        {
            Console.WriteLine($"{numeros[i]}");
        }
            promedioNumeros=sumaNumeros/numeros.Length;
            Console.WriteLine($"La suma de los numeros es de {sumaNumeros}");
            Console.WriteLine($"El promedio de los numeros es de {promedioNumeros}");
    }

}
